import React from 'react';
import Card from './movie/Card'



class Discover extends React.Component {
  render() {
    return (
      <div>Discover
      
      </div>
    );
  }
}
export default Discover;