constructor() {
    //     super()
    //     this.renderCard = this.renderCard.bind(this)
    //     this.renderLargeCard = this.renderLargeCard.bind(this)
    
    //   }
    
    
    //   renderCard() {
    //     const { cities } = this.props
    //     {
    //       cities.map((elem) => {
    //         return (
    
    //           <Card
    //             name={elem.name}
    //             slug={elem.slug}
    //             source={elem.source} />
    //         )
    //       });
    //     }
    //   }
    
    //   renderLargeCard() {
    //     const { cities } = this.props
    //     {
    //       cities.map((elem) => {
    //         return (
    //           <LargeCard
    //             name={elem.name}
    //             slug={elem.slug}
    //             source={elem.source} />
    
    
    //         )
    //       });
    //     }
    //   }
    
    //   render() {
    
    
    //     console.log('hello renderCard', this.renderCard);
    //     // console.log('cities dans home', cities)  
    
    //     return (
    //       <div>
    //         {this.renderCard()}
    //         {this.renderLargeCard()}
    //       </div>
    //     );
    //   }
    // }